class EndPoints{
  static const register = "/user/register";
  static const login = "/user/login";
  static const requestResetPassword = "/user/resetrequest";
  static const requestChangePassword = "/user/resetpassword";
  static const resendOTP = '/user/resendotp';
  static const checkOTP = "/user/checkOtp";
}